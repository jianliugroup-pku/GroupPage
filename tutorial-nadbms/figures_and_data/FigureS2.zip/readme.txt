This archive contains data of the following article,
[1] Baihua Wu, Bingqi Li, Xin He, Xiangsong Cheng, Jiajun Ren, Jian Liu*, "Nonadiabatic Field: A Conceptually Novel Approach for Nonadiabatic Quantum Molecular Dynamics", Journal of Chemical Theory and Computation, 21, 8, 3775-3813 (2025)
