This archive contains data of the following article,
[1] Baihua Wu, Bingqi Li, Xin He, Xiangsong Cheng, Jiajun Ren, Jian Liu*, "Nonadiabatic Field: A Conceptually Novel Approach for Nonadiabatic Quantum Molecular Dynamics", Journal of Chemical Theory and Computation, 21, 8, 3775-3813 (2025)

The following figures contain data from other articles / packages:

Figure 2: The exact results are produced from the MCTDH package:
[2]  Worth, G. A.; Beck, M. H.; Jackle, A.; Meyer, H.-D. The MCTDH Package, Version 8.2, (2000). H.-D. Meyer, Version 8.3
 (2002), Version 8.4 (2007). O. Vendrell and H.-D. Meyer Version 8.5 (2013). Version 8.5 contains the ML-MCTDH algorithm. See http://mctdh.uni-hd.de. (accessed on November 1st, 2023) Used version: 8.5.14.
