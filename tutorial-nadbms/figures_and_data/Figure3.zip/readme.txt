This archive contains data of the following article,
[1] Baihua Wu, Bingqi Li, Xin He, Xiangsong Cheng, Jiajun Ren, Jian Liu*, "Nonadiabatic Field: A Conceptually Novel Approach for Nonadiabatic Quantum Molecular Dynamics", Journal of Chemical Theory and Computation, 21, 8, 3775-3813 (2025)

The following figures contain data from other articles / packages:

Figure 3: The exact result is taken from the following article,
[2] Worth, G. A.; Welch, G.; Paterson, M. J. A Wavepacket Dynamics Study of Cr(CO)5 after Formation by Photodissociation: Relaxation through an (E ⊕ A) ⊗ e Jahn−Teller Conical Intersection. Mol. Phys. 2006, 104, 1095-1105.