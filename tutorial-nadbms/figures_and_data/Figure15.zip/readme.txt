This archive contains data of the following article,
[1] Baihua Wu, Bingqi Li, Xin He, Xiangsong Cheng, Jiajun Ren, Jian Liu*, "Nonadiabatic Field: A Conceptually Novel Approach for Nonadiabatic Quantum Molecular Dynamics", Journal of Chemical Theory and Computation, 21, 8, 3775-3813 (2025)

The following figures contain data from other articles / packages:

Figure 15: The exact results are taken from the following articles,
[2] Hoffmann, N. M.; Schafer, C.; Rubio, A.; Kelly, A.; Appel, H. Capturing Vacuum Fluctuations and Photon Correlations in Cavity Quantum Electrodynamics with Multitrajectory Ehrenfest Dynamics. Phys. Rev. A 2019, 99, No. 063819.
[3] Hoffmann, N. M.; Schäfer, C.; Säkkinen, N.; Rubio, A.; Appel, H.; Kelly, A. Benchmarking Semiclassical and Perturbative Methods for Real-Time Simulations of Cavity-Bound Emission and Interference. J. Chem. Phys. 2019, 151, No. 244113.

