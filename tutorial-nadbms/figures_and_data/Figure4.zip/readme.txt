This archive contains data of the following article,
[1] Baihua Wu, Bingqi Li, Xin He, Xiangsong Cheng, Jiajun Ren, Jian Liu*, "Nonadiabatic Field: A Conceptually Novel Approach for Nonadiabatic Quantum Molecular Dynamics", Journal of Chemical Theory and Computation, 21, 8, 3775-3813 (2025)

The following figures contain data from other articles / packages:

Figure 4: The exact result is taken from the following article,
[2] Green, J. A.; Jouybari, M. Y.; Aranda, D.; Improta, R.; Santoro, F. Nonadiabatic Absorption Spectra and Ultrafast Dynamics of DNA and RNA Photoexcited Nucleobases. Molecules 2021, 26, 1743.

We acknowledge Martha Yaghoubi Jouybari and Fabrizio Santoro for providing the parameters of the LVCM for Thymine in ref [2].
